
@extends('layouts.nav2')

@section('content')
<header>
	@yield('js')
	@section('f')
	<a href="{{ route('home') }}" class="clos" aria-label="Close"><span class="icon-undo2"></span></a>
	@endsection
	@include('modal/modalGrafica')
    {{--<input type="text" style="dysplay:none" id="empresa"  >
<input type="text" style="dysplay:none" id="totalPuntuacion">
<input type="text" id="totalPuntuacion1" style="dysplay:none">--}}
</header>
<section id="conatinerGrafica2">
	<div id="TituloGrafica"><h2>Análisis Ansorff</h2></div>
<div class="btn-group-vertical">

  <button class="botonesGrafica" style="background: #0AB5A0; outline: none;" data-toggle="modal" data-target="#exampleModalCenter"></button>
  <button class="botonesGrafica" style="background: #FC7323; outline: none;" data-toggle="modal" data-target="#exampleModalCenter1"></button>
  <button class="botonesGrafica" style="background: #238276; outline: none;" data-toggle="modal" data-target="#exampleModalCenter2"></button>
  <button class="botonesGrafica" style="background: #003029; outline: none;" data-toggle="modal" data-target="#exampleModalCenter2"></button>
</div>
</section>
<style type="text/css">
    .btn-group-vertical {
        position: absolute;
        margin: 10px 200px;
        z-index: 10;
    }
</style>

<body>

<div style="display: flex; width: 100%; justify-content: center ">
    <div style="display: block; width:700px; height: 400px;">
        <canvas id="ansorff" width="700" height="400"></canvas>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js"></script>

      
<script>

    var Penetración = localStorage.getItem('Penetración');
    var Mercado = localStorage.getItem('Mercado');
    var Producto=   localStorage.getItem('Producto');
   var Diversificación =  localStorage.getItem('Diversificación');
 
const ctx = document.querySelector('#ansorff').getContext('2d')
let a = Penetración;
let b = Mercado;
let c =Producto;
let d = Diversificación;
new Chart(ctx,
{"type":"bar",
"data":
{
    "labels":["Penetración de Mercado","Desarrollo de Mercado","Desarrollo de Producto","Diversificación "],
    "datasets":
        [
            {
                "label":"My First Dataset",
                "data":[a,b,c,d],
                "fill":true,
                "backgroundColor":
                    [
                        "#0ab5a0",
                        "#FC7323",
                        "#00544a",
                        "#003029"

                    ],


                "borderWidth":1
            }
        ]
},
"options":
{
    legend: {
        display: false
    },
    "scales":
        {"yAxes":
                [
                    {
                        "ticks":
                            {
                                "beginAtZero":true,
                                min: 0,
                                max: 100
                            }
                    }
                ]
        }
}
});

</script>


</body>


  {{-- href="http://127.0.0.1:8000/analisisDofaInfo" --}}
 <!-- <a  href="{{ route('analisisDofaInfo') }} "  style="color:white; justify-content: center; " name="nuevo" class="Ahora btn btn-planeem waves-effect waves-light">Siguiente</a>-->

  <a  href="{{ route('estrategiaInfo') }} "  style="color:white; justify-content: center; " name="nuevo" class="Ahora btn btn-planeem waves-effect waves-light">Siguiente</a>

<span class="icon-info" data-toggle="modal" data-target="#exampleModalScrollable" style="cursor:pointer;"></span>
<div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
	<div class="modal-dialog modal-dialog-scrollable" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalCenterTitle" style="margin-left: 252px; font-weight: bold;"></h5>
				<span class="icon-cancel-circle" style="color:#FC7323; font-size: 32px; cursor: pointer; margin-top: 4px;
				margin-left: 10%;" data-dismiss="modal" aria-label="Close"></span>

			</div>
			<div class="modal-body">
				<p>
					Como realizar la calificación de la Matriz PCI (Perfil de Capacidad interna)

					Para realizar la calificación de la matriz se debe seleccionar la capacidad, identificar si
					es una fortaleza o debilidad para la empresa, luego si:
					<br><br>
					1. Es una fortaleza se debe calificar D si es débil (débil), M si es (media) y A si es (alta)
					<br>
					2. Es debilidad debo calificar si es D si es débil (débil), M si es (media) y A si es (alta)
					Luego, se califica que impacto tiene esa debilidad o fortaleza para la empresa: D(débil),
					M (media), A(alta)
				</p>
			</div>
		</div>
	</div>
@yield('script')
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

<script>

  $(document).ready(function () {
   $('.items li:nth-child(12)').addClass("acti");
   $('.items li').click(function () {
    $('.items li').removeClass("acti");
    $(this).addClass("acti");


  })

   $('.valores').mouseenter(function(){
    let mensaje = $(this).attr('mensaje');

    $('.hover').html(`<p>${mensaje}</p>`)
    $('.hover').show()

  })
   $('.valores').mouseleave(function(){

    $('.hover').hide()
  })
 })
</script>

@endsection
