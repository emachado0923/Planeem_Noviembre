						<div class="modal fade" id="exampleModaleditar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado2">
									<div class="modal-body">
										<button type="button" class="close" data-dismiss="modal" aria-label="Close" style="outline: none;margin-left: 97% !important;">
											<span class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></span>
										</button>
										<div class="ingresevalor">
											<input type="text" class="campo2" name="nombreEmpresa" value="" placeholder="Ingresa tú nombre" style="background: none; outline:none;font-size: 20px;">

										</div>
										<br>
										<a  data-dismiss="modal" aria-label="Close" style="color:white;" class="aceptarvalor btn btn-planeem waves-effect waves-light">Aceptar</a>
									</div>
								</div>
							</div>
						</div>


{{-- modales de la vista diagnostico estrategico - Capacidad interna --}}

{{--     Modal: diagnostico estrategico - Perfil capacidad interna - Capacidad Directiva - información de debilidades--}}

                        <div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 9000;">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado1">
									<div class="modal-body">
										<div id="cierre_caja4"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 93%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
                                            <p class="Nota" style="margin-left: 0.5px; font-weight: bold; font-size: 15px"; >Debilidades:</p>
                                                <p>Son aquellos factores internos que generan una posición
                                                desfavorable frente a la competencia, por ejemplo, recursos y habilidades
                                                de las que carece o actividades que no se desarrollan de la mejor manera
                                                en la organización. 1q1</p>
										</div>
									</div>
								</div>
							</div>
						</div>



{{--     Modal: diagnostico estrategico - Perfil capacidad interna - Capacidad Directiva - información de fortalezas--}}

                        <div class="modal fade" id="exampleModal3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 9000;">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado1">
									<div class="modal-body">
										<div id="cierre_caja4"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 93%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
                                            <p class="Nota" style="margin-left: 0.5px; font-weight: bold; font-size: 15px"; >Fortaleza:</p>
                                            <p>Son las capacidades esenciales con las que cuenta la compañía,
                                                que le permiten obtener una posición privilegiada frente a la
                                                competencia, por ejemplo, recursos y habilidades que se poseen
                                                o actividades que se desarrollan de forma adecuada. 2q2*****</p>
										</div>
									</div>
								</div>
							</div>
						</div>



{{--     Modal: diagnostico estrategico - Perfil capacidad interna - Capacidad Directiva - información No Aplica--}}

                        <div class="modal fade" id="exampleModal4" tabindex="-8" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 9000;">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado1">
									<div class="modal-body">
										<div id="cierre_caja7"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 93%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
                                            <p class="Nota" style="margin-left: 0.5px; font-weight: bold; font-size: 15px"; >No Aplica:</p>
                                            <p>es este ítem es para indicar que no es ni una debilidad ni
                                                fortaleza o simplemente un factor no se relaciona con las
                                                actividades que realiza la empresa. 3q3</p>
										</div>
									</div>
								</div>
							</div>
						</div>

                        <div class="modal fade" id="FactoresClavePerfilCompetitivo" tabindex="-8" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 9000;">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content modal-modificado1">
                                    <div class="modal-body">
                                        <div id="cierre_caja7"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 93%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
                                            <p class="Nota" style="margin-left: 0.5px; font-weight: bold; font-size: 15px"; >Los Factores Claves:</p>
                                            <p>son las áreas claves, que deben llevarse al nivel más alto posible
                                                de excelencia si la empresa quiere tener éxito en una industria
                                                en particular. Estos factores varían entre diferentes industrias
                                                o incluso entre diferentes grupos estratégicos e incluyen tanto
                                                factores internos como externos.  3qssss</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="modal fade" id="PonderacionPerfilCompetitivo" tabindex="-8" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 9000;">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content modal-modificado1">
                                    <div class="modal-body">
                                        <div id="cierre_caja7"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 93%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
                                            <p class="Nota" style="margin-left: 0.5px; font-weight: bold; font-size: 15px"; >Ponderación:</p>
                                            <p>Asigne un peso entre 0.0 (no importante) hasta 1.0 (muy importante),
                                                el peso otorgado a cada factor expresa la importancia relativa del mismo,
                                                y el total de todos los pesos en su conjunto debe tener la suma de 1.0.  1qssss</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="modal fade" id="CalificaciónPerfilCompetitivo" tabindex="-8" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 9000;">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content modal-modificado1">
                                    <div class="modal-body">
                                        <div id="cierre_caja7"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 93%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
                                            <p class="Nota" style="margin-left: 0.5px; font-weight: bold; font-size: 15px"; >Calificación:</p>
                                            <p>Asignar una calificación a cada variable, esta calificación es de 1 a 4. Siendo:<br>
                                                1: Debilidad Mayor.<br>
                                                2: Debilidad Menor<br>
                                                3: Fortaleza Menor.<br>
                                                4: Fortaleza Mayor.
                                                2qssss</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="modal fade" id="PuntuaciónPonderadaPerfilCompetitivo" tabindex="-8" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 9000;">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content modal-modificado1">
                                    <div class="modal-body">
                                        <div id="cierre_caja7"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 93%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
                                            <p class="Nota" style="margin-left: 0.5px; font-weight: bold; font-size: 15px"; >Puntuación Ponderada:</p>
                                            <p>Es la multiplicación de la ponderación por la calificación asignada (esta es automática)
                                                3qssss</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

						<div class="modal fade" id="exampleModal5" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 9000;">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado1">
									<div class="modal-body">
										<div id="cierre_caja7"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 93%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
                                            <p class="Nota" style="margin-left: 0.5px; font-weight: bold; font-size: 15px"; >Debilidades:</p>
                                            <p>Son aquellos factores internos que generan una posición
                                                desfavorable frente a la competencia, por ejemplo, recursos y habilidades
                                                de las que carece o actividades que no se desarrollan de la mejor manera
                                                en la organización. 4q4</p>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModal6" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado1">
									<div class="modal-body">
										<div id="cierre_caja6"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 93%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
                                            <p class="Nota" style="margin-left: 0.5px; font-weight: bold; font-size: 15px"; >Fortaleza:</p>
                                            <p>Son las capacidades esenciales con las que cuenta la compañía,
                                                que le permiten obtener una posición privilegiada frente a la
                                                competencia, por ejemplo, recursos y habilidades que se poseen
                                                o actividades que se desarrollan de forma adecuada.5q5</p>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModal7" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado1">
									<div class="modal-body">
										<div id="cierra_caja5"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 93%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
                                            <p class="Nota" style="margin-left: 0.5px; font-weight: bold; font-size: 15px"; >No Aplica:</p>
                                            <p>es este ítem es para indicar que no es ni una debilidad ni
                                                fortaleza o simplemente un factor no se relaciona con las
                                                actividades que realiza la empresa.6q6</p>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModal8" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado1">
									<div class="modal-body">
										<div id="cierre_caja4"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 93%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
                                            <p class="Nota" style="margin-left: 0.5px; font-weight: bold; font-size: 15px"; >Debilidades:</p>
                                            <p>Son aquellos factores internos que generan una posición
                                                desfavorable frente a la competencia, por ejemplo, recursos y habilidades
                                                de las que carece o actividades que no se desarrollan de la mejor manera
                                                en la organización.7q7</p>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModal9" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado1">
									<div class="modal-body">
										<div id="cierre_caja7"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 93%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
                                            <p class="Nota" style="margin-left: 0.5px; font-weight: bold; font-size: 15px"; >Fortaleza:</p>
                                            <p>Son las capacidades esenciales con las que cuenta la compañía,
                                                que le permiten obtener una posición privilegiada frente a la
                                                competencia, por ejemplo, recursos y habilidades que se poseen
                                                o actividades que se desarrollan de forma adecuada.8q8</p>
										</div>

									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModal10" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado1">
									<div class="modal-body">
										<div id="cierre_caja6"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 93%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
                                            <p class="Nota" style="margin-left: 0.5px; font-weight: bold; font-size: 15px"; >No Aplica:</p>
                                            <p>es este ítem es para indicar que no es ni una debilidad ni
                                                fortaleza o simplemente un factor no se relaciona con las
                                                actividades que realiza la empresa.9q9</p>
										</div>

									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModal12" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado1">
									<div class="modal-body">
										<div id="cierre_caja4"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 93%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
											<p class="Nota">Nota:  exampleModal12   El perfil de fortalezas y debilidades,
                                                se representa gráficamente mediante la calificación de la fortaleza o debilidad
                                                con relación a su grado en la escala de Alto (A), Medio (M), y Bajo (B).12q12</p>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModal13" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado1">
									<div class="modal-body">
										<div id="cierre_caja7"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 93%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
											<p class="Nota">Nota:  exampleModal13   Son los factores internos que obstaculizan
                                                el logro de los objetivos planteados, incluyendo actividades y atributos internos
                                                de una organización que inhiben o dificultan el éxito de una empresa. (Prieto 2008)..13q13</p>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModal11" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado1">
									<div class="modal-body">
										<div id="cierre_caja6"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 93%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
											<p class="Nota">Nota:  exampleModal11   Son todas las capacidades, atributos y recursos de una organización que contribuyen y apoyan el
											logro de los objetivos planificados con el fin de obtener ventajas competitivas. (Serna, 2010)...11q11</p>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModal14" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado1">
									<div class="modal-body">
										<div id="cierre_caja4"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 93%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
                                            <p class="Nota" style="margin-left: 0.5px; font-weight: bold; font-size: 15px"; >Fortaleza:</p>
                                            <p>Son las capacidades esenciales con las que cuenta la compañía,
                                                que le permiten obtener una posición privilegiada frente a la
                                                competencia, por ejemplo, recursos y habilidades que se poseen
                                                o actividades que se desarrollan de forma adecuada....14q14</p>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModal15" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado1">
									<div class="modal-body">
										<div id="cierre_caja7"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 93%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
											<p class="Nota">Nota:    exampleModal15    Son los factores internos que obstaculizan
                                                el logro de los objetivos planteados, incluyendo actividades y atributos internos
                                                de una organización que inhiben o dificultan el éxito de una empresa. (Prieto 2008)...15q15</p>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModal16" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado1">
									<div class="modal-body">
										<div id="cierre_caja6"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 93%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
											<p class="Nota">Nota:  exampleModal16   Son todas las capacidades, atributos y recursos de una organización que contribuyen y apoyan el
											logro de los objetivos planificados con el fin de obtener ventajas competitivas. (Serna, 2010)....16q16</p>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModal21" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado2">
									<div class="modal-body">
										<div class="añadircapacidad">
											<textarea maxlength="504"  id="Descripción" style="color:black;" class="campo4"></textarea>
										</div>
										<div><a style="color:white;" data-dismiss="modal" aria-label="Close" class="aceptarcapacidad btn btn-planeem waves-effect waves-light">Añadir</a>
										</div>
										<div id="cancelar">
											<a value="cierra_AñadirCapa" class="cancelarcapacidad btn btn-planeem waves-effect waves-light" data-dismiss="modal" aria-label="Close" style=" outline: none !important;">Cancelar</a>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
							<div class="modal-dialog modal-dialog-scrollable" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<h5 class="modal-title" id="exampleModalCenterTitle" style="margin-left: 252px; font-weight: bold;"></h5>
										<span class="icon-cancel-circle" style="color:#FC7323; font-size: 25px; cursor: pointer; margin-top: 4px;
										margin-left: 10%;" data-dismiss="modal" aria-label="Close"></span>

									</div>
									<div class="modal-body">
                                        <p class="Nota" style="margin-left: 0.5px; font-weight: bold; font-size: 15px"; >Desarrollo de la Matriz de Perfil Competitivo:</p>
                                        <p style="text-align: justify;">Para desarrollar la matriz de Perfil Competitivo debe seguir los siguientes pasos:<br>

                                            1. Identificar los factores críticos de éxito con los cuales se comparará su empresa con la competencia. De la lista que se le muestra seleccione los 10 factores con mayor relevancia.

                                            3. Asigne un peso entre 0.0 (no importante) a 1.0 (absolutamente importante) a cada uno de los factores identificados.

                                            4. Asigne una calificación entre 1 y 4 a cada uno de los factores donde:
                                            1.=Mayor debilidad
                                            2.=Menor debilidad
                                            3.=Menor fuerza
                                            4.=Mayor fuerza

                                            5. Seleccione los competidores de su empresa. (Mínimo 1 Máximo 5) con los cuales se comparará y califique los criterios antes seleccionados teniendo cuenta la misma escala de calificación.

                                            6. Comparar los puntajes para tomar medidas teniendo en cuenta lo siguiente:

                                            Un total por debajo de 2,5 indica que las empresas son débiles interna mente, mientras que un valor superior a 2,5 refleja una posición interna fuerte.

                                            La empresa que obtenga el mayor puntaje se considerará el jugador más fuerte en términos competitivos.

                                            ¡Empecemos!........{modal.blade---linea 371}</p>
									</div>
								</div>
							</div>
						</div>


                        <div class="modal fade" id="exampleModalScrollable1" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-scrollable" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalCenterTitle" style="margin-left: 252px; font-weight: bold;"></h5>
                                        <span class="icon-cancel-circle" style="color:#FC7323; font-size: 25px; cursor: pointer; margin-top: 4px;
										margin-left: 10%;" data-dismiss="modal" aria-label="Close"></span>

                                    </div>
                                    <div class="modal-body">
                                        <p class="Nota" style="margin-left: 0.5px; font-weight: bold; font-size: 15px"; >Desarrollo del Análisis Pestal:</p>
                                        <p style="text-align: justify;">
                                            A continuación, se habilitará una lista de factores en los cuales encontrará aspectos Políticos, Económicos, Sociales, Tecnológicos, Ambientales y Legales.<br>

                                            Lo invitamos a seguir los siguientes pasos:<br>

                                            1) Identifique si los factores mencionados representan para su empresa una oportunidad o amenaza<br>
                                            2) Después debe asignar una calificación a cada factor considerando su importancia de la siguiente manera:<br>
                                            A (si es alto), M (si es medio), B (si es bajo).<br><br>
                                            En caso de no aplicar se puede marcar la opción N/A<br>


                                            {modal.blade---linea 409}</p>
                                    </div>
                                </div>
                            </div>
                        </div>





						<div class="modal fade" id="exampleModal0" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado2">
									<div class="modal-body">
										<div class="añadircapacidad">
											<textarea maxlength="504"  id="Descripción" style="color:black;" class="campo4"></textarea>
										</div>
										<div><a style="color:white;" data-dismiss="modal" aria-label="Close" class="aceptarcapacidad btn btn-planeem waves-effect waves-light">Añadir</a>
										</div>
										<div id="cancelar">
											<a value="cierra_AñadirCapa" class="cancelarcapacidad btn btn-planeem waves-effect waves-light" data-dismiss="modal" aria-label="Close" style=" outline: none !important;">Cancelar</a>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModal001" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado1">
									<div class="modal-body">
										<div id="cierre_caja4"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 93%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
											<p class="Nota">Nota: El perfil de fortalezas y debilidades, se representa gráficamente mediante la calificación de la fortaleza o debilidad con
											relación a su grado en la escala de Alto (A), Medio (M), y Bajo (B).001q001</p>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="z-index: 9000;">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado4">
									<div class="modal-body">
										<div id="cierre_proveedores"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 97%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
											<p style="line-height: 17px; margin-top: 2px;">
												<b style="color: black; font-weight: bold; text-align: center;">Análisis Político</b>
												<br><br>
                                                Son aquellos factores asociados a la clase política que puedan determinar
                                                e influir en la actividad de la empresa en el futuro, las diferentes políticas
                                                de los gobiernos locales, nacionales, continentales e incluso mundiales.
                                                Es importante entender la globalidad de lo que ocurre y sus relaciones,
                                                las normativas comerciales y aranceles. {Modal, linea 452}
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModal55" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado4">
									<div class="modal-body">
										<div id="cierre_proveedores"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 97%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
											<p style="line-height: 17px; margin-top: 2px;">
												<b style="color: black; font-weight: bold; text-align: center;">Poder de negociación de lo clientes</b>
												<br><br>
												Un mercado o segmento no será atractivo cuando los clientes están muy bien
												organizados, el producto tiene varios o muchos sustitutos, el producto no es muy
												diferenciado o es de bajo costo para el cliente, lo que permite que pueda hacer
												sustituciones por igual o a muy bajo costo.
												A mayor organización de los compradores mayores serán sus exigencias en materia de
												reducción de precios, mayor calidad y servicios y por consiguiente la corporación tendrá
												una disminución en los márgenes de utilidad.
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModal511" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado4">
									<div class="modal-body">
										<div id="cierre_proveedores"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 97%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
											<p style="line-height: 17px; margin-top: 2px;">
												<b style="color: black; font-weight: bold; text-align: center;">Poder de negociación de lo clientes</b>
												<br><br>
												Un mercado o segmento no será atractivo cuando los clientes están muy bien
												organizados, el producto tiene varios o muchos sustitutos, el producto no es muy
												diferenciado o es de bajo costo para el cliente, lo que permite que pueda hacer
												sustituciones por igual o a muy bajo costo.
												A mayor organización de los compradores mayores serán sus exigencias en materia de
												reducción de precios, mayor calidad y servicios y por consiguiente la corporación tendrá
												una disminución en los márgenes de utilidad.
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModal999" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado4">
									<div class="modal-body">
										<div id="cierre_proveedores"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 97%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
											<p style="line-height: 17px; margin-top: 2px;">
												<b style="color: black; font-weight: bold; text-align: center;">Productos Sustitutos</b>
												<br><br>
												Un mercado o segmento no es atractivo si existen productos sustitutos
                                                reales o potenciales. La situación se complica si los sustitutos están
                                                más avanzados tecnológicamente o pueden entrar a precios más bajos reduciendo
                                                los márgenes de utilidad de la empresa y del sector. Para este tipo de modelo
                                                tradicional, la defensa consiste en construir barreras de entrada alrededor
                                                de una fortaleza que tuviera la empresa y que le permitiera, mediante la
                                                protección que le otorga esta ventaja competitiva, obtener utilidades que
                                                luego podía utilizar en investigación y desarrollo, para financiar una
                                                guerra de precios o para invertir en otros negocios.
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModal134" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado4">
									<div class="modal-body">
										<div id="cierre_proveedores"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 97%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
											<p style="line-height: 17px; margin-top: 2px;">
												<b style="color: black; font-weight: bold; text-align: center;">Productos Sustitutos</b>
												<br><br>
												Un mercado o segmento no es atractivo si existen productos
                                                sustitutos reales o potenciales. La situación se complica
                                                si los sustitutos están más avanzados tecnológicamente o
                                                pueden entrar a precios más bajos reduciendo los márgenes
                                                de utilidad de la empresa y del sector. Para este tipo de
                                                modelo tradicional, la defensa consiste en construir barreras
                                                de entrada alrededor de una fortaleza que tuviera la empresa
                                                y que le permitiera, mediante la protección que le otorga esta
                                                ventaja competitiva, obtener utilidades que luego podía utilizar
                                                en investigación y desarrollo, para financiar una guerra de
                                                precios o para invertir en otros negocios.
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModal135" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado4">
									<div class="modal-body">
										<div id="cierre_proveedores"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 97%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
											<p style="line-height: 17px; margin-top: 2px;">
												<b style="color: black; font-weight: bold; text-align: center;">Productos Sustitutos</b>
												<br><br>
												Un mercado o segmento no es atractivo si existen productos
                                                sustitutos reales o potenciales. La situación se complica
                                                si los sustitutos están más avanzados tecnológicamente o pueden
                                                entrar a precios más bajos reduciendo los márgenes de utilidad
                                                de la empresa y del sector. Para este tipo de modelo tradicional,
                                                la defensa consiste en construir barreras de entrada alrededor
                                                de una fortaleza que tuviera la empresa y que le permitiera,
                                                mediante la protección que le otorga esta ventaja competitiva,
                                                obtener utilidades que luego podía utilizar en investigación y
                                                desarrollo, para financiar una guerra de precios o para invertir
                                                en otros negocios.
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModal99" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado4">
									<div class="modal-body">
										<div id="cierre_proveedores"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 97%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
											<p style="line-height: 17px; margin-top: 2px;">
												<b style="color: black; font-weight: bold; text-align: center;">Productos Sustitutos</b>
												<br><br>
												Un mercado o segmento no es atractivo si existen productos sustitutos
                                                reales o potenciales. La situación se complica si los sustitutos están
                                                más avanzados tecnológicamente o pueden entrar a precios más bajos
                                                reduciendo los márgenes de utilidad de la empresa y del sector. Para
                                                este tipo de modelo tradicional, la defensa consiste en construir
                                                barreras de entrada alrededor de una fortaleza que tuviera la empresa
                                                y que le permitiera, mediante la protección que le otorga esta ventaja
                                                competitiva, obtener utilidades que luego podía utilizar en investigación
                                                y desarrollo, para financiar una guerra de precios o para invertir en otros negocios.
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModal131" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado4">
									<div class="modal-body">
										<div id="cierre_proveedores"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 97%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
											<p style="line-height: 17px; margin-top: 2px;">
												<b style="color: black; font-weight: bold; text-align: center;">Amenazas de entrada de nuevos competidores</b>
												<br><br>
												El mercado o el segmento no son atractivos dependiendo de si las barreras de entrada

												son fáciles o no de franquear por nuevos participantes que puedan llgaar con nuevos
												recursos y capacidades para apoderarse de una porción del mercado.
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="modal fade" id="exampleModal177" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog" role="document">
								<div class="modal-content modal-modificado4">
									<div class="modal-body">
										<div id="cierre_proveedores"><a data-dismiss="modal" aria-label="Close" style="background: white; outline: none !important; margin-left: 97%"><i class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></i></a>
											<p style="line-height: 17px; margin-top: 2px;">
												<b style="color: black; font-weight: bold; text-align: center;">Rivalidad entre competidores</b>
												<br><br>
												Para una organización será más difícil competir en un mercado o en uno de sus
												segmentos donde los competidores estén muy bien posicionados, sean muy numerosos y
												los costos fijos sean altos, pues constantemente estará enfrentada a guerras de precios,
												campañas publicitarias agresivas, promociones y entrada de nuevos productos.
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>
