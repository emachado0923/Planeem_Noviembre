	<div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content modal-modificado3">
				<div class="modal-body" style="padding: 0 !important;">
					<div id="campo_texto"  class="campo_Objetivo">
						<h3 style="text-align: center;">Ejemplo Formulario</h3>
						<main class="indicadores2">
							<div>
								<input type="text" name=""  placeholder="Objetivo" class="inputIndicador">
							</div>
						</main>
						<span class="icon-arrow-down2 icono-down" ></span>
						<main class="indicadores">
							<div>
								<input type="text" name="" placeholder="Nombre del indicador" class="inputIndicador">
							</div>
						</main>
						<span class="icon-arrow-down2 icono-down" ></span>
						<main class="indicadores">
							<div>
								<input type="text" name="" placeholder="Que quiere medir" class="inputIndicador">
							</div>
						</main>
						<hr class="division">
						<main class="indicadores">
							<div>
								<input type="text" name="" placeholder="Sobre que lo quiere medir" class="inputIndicador">
							</div>
						</main>
					</div>

					<a data-dismiss="modal" aria-label="Close" style="color:white;" class="guardarEstrategia btn btn-planeem waves-effect waves-light">Guardar</a>
				</div>
			</div>
		</div>
	</div>

