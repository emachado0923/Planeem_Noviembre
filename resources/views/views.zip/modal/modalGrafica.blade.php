
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content modal-modificadoEFI ">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle"></h5>
      <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="outline: none;margin-left: 0% !important;" >
       <span class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></span>
     </button>
      </div>
      <div class="modal-body">
        <h2><img src="img/crecer.png" style="margin: 12px;">Crecer y construir:</h2>
        <p style="font-size: 21px;text-align: justify;">
          Desarrollar estrategias intensivas como (penetración en el mercado,
          desarrollo del mercado o desarrollo del producto) o las integrativas como
          (integración hacia atrás, integración hacia delante e integración horizontal)
          tal vez sean las más convenientes para estas
          divisiones.
        </p>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="exampleModalCenter1" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content modal-modificadoEFI ">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle"></h5>
      <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="outline: none;margin-left: 0% !important;" >
       <span class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></span>
     </button>
      </div>
      <div class="modal-body">
        <h2><img src="img/retener.png" style="margin: 12px;">Retener y mantener:</h2>
        <p style="font-size: 21px;text-align: justify;">
            En esta división se debe implementar la penetración en el mercado
            y el desarrollo del producto son dos estrategias comúnmente
            empleadas para este tipo de divisiones.
            En tercero, una recomendación frecuente para las divisiones que
            caen en las celdas.
        </p>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="exampleModalCenter2" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content modal-modificadoEFI ">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle"></h5>
      <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="outline: none;margin-left: 0% !important;" >
       <span class="icon-cancel-circle" style="color: #FC7323; font-size: 21px;margin-top: 2%; cursor: pointer;"></span>
     </button>
      </div>
      <div class="modal-body">
        <h2><img src="img/Cosechar.png" style="margin: 12px;">Cosechar o desinvertir:</h2>
        <p style="font-size: 21px;text-align: justify;">
            <b style="font-weight: bold">Estrategia de desinversión:</b><br>
            Es la venta de una parte de la empresa o actividades.
            Esta estrategia supone una reestructuración de la empresa.
            <br>
            <b style="font-weight: bold">Estrategia de cosecha:</b><br>
            Reducir inversiones en una actividad para reducir costos
        </p>
      </div>
    </div>
  </div>
</div>